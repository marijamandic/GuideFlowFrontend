export interface AuthenticationResponse {
    id: number;
    accessToken: string;
  }