export interface PagedResults<T>{
    results: T[];
    totalCount: number;
}
  