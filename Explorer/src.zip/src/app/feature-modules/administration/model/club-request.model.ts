export interface ClubRequest{
    id?: number,
    clubId: number,
    touristId: number,
    status: string
}