export const environment = {
    production: false,
    apiHost: 'https://localhost:44333/api/',
  };
  